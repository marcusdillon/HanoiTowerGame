//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================


/** Defines the class GameState
 * @author Marcus Dillon
 * @version 1.0
 * @since 1.0
 * @param N/A 
 * @return N/A 
 * This class is a enumeration class. The value which are represented this class are PLAYING, LOSER and WINNER. These values will be used to
 * represent the state of the game. This will be used in HanoiTowerGame in the checkWinner method and in the HumanPlayer(play() method) to 
 * determine when the player should stop playing.
*/

public enum GameState {
	// states wanted are: PLAYING, LOSER, and WINNER
    PLAYING,
    LOSER,
    WINNER
}