//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================

/** Defines the class LinkedStack.
 * @author Marcus Dillon
 * @version 1.0
 * @since 1.0
 * @param N/A 
 * @return N/A 
 * This class defines the LinkedStack. A linked stack allocates memory dynamically so it is perfect for our situtation given we want to change the size of our stacks depending on 
 * if where we play our moves. This class will allow us to create objects of type LinkedStack which will be used to represent the three HanoiTowers. We will able to perform basic stack operations on
 * those towers such as push, pop, isempty, size etc... to allow us to build our HanoiTowerGame.
*/

public class LinkedStack implements Stack {



    /** Defines the class Elems.
     * @author Marcus Dillon
     * @version 1.0
     * @since 1.0
     * @param value --> value of the element (size of disk in our case)
     * @param next --> reference to the next Elem
     * @return N/A 
     * This class defines Elem. An elem is an object which contains a value and a reference to the next elem. This way, we can go through a stack by checking which Element is attached to our current element. 
     * This will be used in our implementation of LinkedStack as it will allow us to link our values together and treat our towers as a stack. It contains getters and setters to change the value and reference. 
     * 
    */
    public class Elem {
        public Object value;
        public Elem next;
    
        /**
        * This method is our constructor for the class Elem. It handles cases where we do not specify the value and reference to our next object. 
        * <p>
        * @author Marcus Dillon
        * @param  NA
        * @return void
        */
        Elem() {
            this.value = null;
            this.next = null;
        }   

        /**
        * This method is our second constructor for the class Elem. It handles cases where we specify the value and reference to our next object. These will be assigned the values in
        * the parameters and will be used to house the value of the size of our disks. This will enable us to compare disk sizes to determine which disk is bigger then the other.  
        * <p>
        * @author Marcus Dillon
        * @param  value --> size of the disk
        * @param  next --> reference to the next disk 
        * @return void
        */
        Elem (Object value, Elem next) {
            this.value = value;
            this.next = next;
        }

        /**
        * This method is a setter for our Elem objects. It will allow us to dynamically change the values of our objects in case we would like to create or modify a copy of a LinkedStack. 
        * <p>
        * @author Marcus Dillon
        * @param  value --> size of the disk
        * @return void
        */
        public void setValue(Object value) {
            this.value = value;
        }

        /**
        * This method is a setter for our Elem objects. It will allow us to dynamically change the object to which we are referencing with our current Elem. This will be used if we wish to modify a stack by replacing
        * a Elem with another or if we wish to nulify a value contained within our stack. 
        * <p>
        * @author Marcus Dillon
        * @param  next --> reference to next disk
        * @return void
        */
        public void setNext(Elem next) {
            this.next = next;
        }

        /**
        * This method is a getter for our Elem class. It enables us to get the value contained within an Elem. This will be used 
        * in order to compare values of our elements to see if we can perform certain operations. For example, checking if one value is larger
        * then the other would indicate a invalid move. 
        * <p>
        * @author Marcus Dillon
        * @param  NA
        * @return Object --> value of the elem 
        */
        public Object getValue() {
            return value;
        }

        /**
        * This method is a getter for our Elem class. It enables us to get the reference to the next Elem in our stack. 
        * This method will be used in our pop() method as we change the value of top to null in order to remove that last element 
        * and return its value back.
        * 
        * <p>
        * @author Marcus Dillon
        * @param  NA
        * @return Elem --> reference to the next element 
        */
        public Elem getNext() {
            return next;
        }
    }

    private Elem top;
    private int size;


    /**
    * This is our constructor for the LinkedStack class. It will be used in cases where we want to create an empty stack.
    * This will be used specifically in the HanoiTowersGame constructor as we create three new LinkedStacks using this method. 
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return void
    */
    LinkedStack() {
        top = null;
    }
	
    /**
    * This is the implementation of the isEmpty() method found in the Stack Interface. As previously explained, it returns True
    * if the stack is empty and false otherwise. This will be used in our play() method as we check to see if our source tower contains elements or not.
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return void
    */
    public boolean isEmpty( ){
        return top == null;
    }

    /**
    * This is the implementation of the push() method found in the Stack Interface. As previously explained, it takes an object 
    * as input and inserts it at the top of the given stack. It also increases the stack size by one and sets the top equal to the newly
    * added element.
    * <p>
    * @author Marcus Dillon
    * @param  o --> object we want to push
    * @return void
    */
    public void push( Object o ){
        if (top == null) {
            top = new Elem(o,null);
            size++;
        } else {
            Elem temp = new Elem(o,top);
            top = temp;
            size++;
        }
    }

    /**
    * This is the implementation of the pop() method found in the Stack Interface. As previously explained, it saves the value of the 
    * current top element temporarly and returns it. It also removes the top element and sets it value and reference to null. We will use 
    * method whenever we want to add a disk to a HanoiTower using the play() method
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return Object
    */
    public Object pop( ){
        Elem temp;

        if (isEmpty()) 
            return null;

        temp = top;
        top = top.getNext();
        temp.setNext(null);
        size--;
        return temp.getValue();
    }

    /**
    * This is the implementation of the peek() found in the Stack interface. This method returns the top element of the stack without 
    * removing it. This allows us to compare values of the size of disks to check for compliance when doing moves in the play method. 
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return Object --> top element of stack 
    */
    public Object peek( ){
        return top.getValue();
    }

    /**
    * This is the implementation of the size() found in the Stack interface. This method returns size of the given stack. We will be using this 
    * getDisksAtTower() method which will be our main method of checking the size of the stacks. If the top is equal to null, we return 0.
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return int --> size of stack  
    */
    public int size( ){
        if (top == null) {
            return 0;
        } else {
            return size;
        }

    }

     /**
    * This is the implementation of toString for the stack. This is what dictactes what will be printed when we print our stack. We print it in the
    * format [1,2,3]. This format will be used for printing the stack in the HanoiTowerGame class by parsing the values in this string. 
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return String --> String representation of the stack  
    */
    public String toString() {
        String res = "[";
        if (top != null) {
            Elem p = top;
            res = res + p.value;
            p = p.next;
            while (p !=null) {
                res = res + "," + p.value;
                p = p.next;
            }
        }
        res = res + "]";
        return res; 
    }



}