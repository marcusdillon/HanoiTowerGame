//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================

/** Defines the interface Stack.
 * @author Marcus Dillon
 * @version 1.0
 * @since 1.0
 * @param N/A no constructor 
 * @return N/A 
 * This class defines the stack interface. It mimics the classic Java built-in Stack interface with the methods 
 * isEmpty(), push(), pop(), peek(), size(). This class will implemented in the LinkedStack class. We will use these linked
 * stacks to represent the hanoi towers for our game. The reason for this being we can only remove the top element of the stack.
 * 
*/

public interface Stack {
	//your code here

    /**
    * This method checks to see if the stack contains elements. If the stack is empty, it returns true. Otherwise,
    * it will return false. This method will be used in LinkedStack to help determine which HanoiTower currently contains elements. 
    * <p>
    * @author Marcus Dillon
    * @return boolean 
    */
    boolean isEmpty( );

    /**
    * This method will be used in our LinkedStack to push elements onto our HanoiTowers. We can only push elements on the top of the tower, given
    * the use of a stack. 
    * <p>
    * @author Marcus Dillon
    * @param  o -> Object we want to push in the stack
    * @return void
    */
    void push( Object o );

    /**
    * This method will be used in our LinkedStack to pop (remove and return) values from the top of our stack. This will be used for HanoiTowers when we 
    * are trying to move from one stack to another. We return the Object which was situated at the TOP of the stack only and set its value to NULL. 
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return Object
    */
    Object pop( );

    /**
    * This method will be used in our LinkedStack to verify the values at the top of the tower without removing the Object. This is useful for situations where
    * we want to verify that the element is not null or if we want to check the size of the top element to determine wether or not we can push() and element onto that
    * stack. 
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return Object
    */
    Object peek( );

    /**
    * This method will be used in our LinkedStack to check the size of our current stack. This will be particulalry useful for determining when the game has been won as we
    * can compare the size of a stack to the maximum amount of disks available in that particular game. 
    * <p>
    * @author Marcus Dillon
    * @param  NA
    * @return int -> Size of the stack 
    */
    int size( );
}