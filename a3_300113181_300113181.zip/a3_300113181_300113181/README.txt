Assignment 3
ITI 1121 - Section A
Student: Marcus Dillon
Student #: 300113181
Team: Worked Alone

This folder contains the files GameState.java, HanoiTower.java, HanoiTowergame.java, HumanPlayer.java, LinkedStack.java, Player.java, Stack.java, Studentino.java and Utils.java. 

Description: This assignment consisted of creating a version of the HanoiTowerGame. In this game, players move disks from one tower to another using 
a third tower as temporary storage. This game is played by two people and the score of each player is tracked throughout the duration of the game. 