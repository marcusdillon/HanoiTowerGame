//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================



/** Defines the class HanoiTowerGame
 * @author Marcus Dillon
 * @version 1.0
 * @since 1.0
 * This class is the class responsible for creating an Array of 3 linked stacks. These stacks represent the Hanoi
 * Towers which will be used to play the game. This class also defines getters for variables such as
 * the disks, level, max level,gameState, disksattower etc.. This class also contains the method play() which takes the input
 * and performs the proper play on the board. It also has a toString method which is used to print the array.
*/

import java.lang.Math;
import java.util.Arrays;
import java.io.*;


public class HanoiTowerGame {

	//MR:This will point to the array of three towers (type of towers LinkedStack)
	private Stack[] towerValues;  

	//MR:your code here

	//Instance variables 
	private int level;
	private int maxLevels;
	private GameState gameState;
	private int disks;

	// MR:all methods should be documented: purpose of the method, input, and output
	// MR:and where it is used in the assignment

	/** Defines the method HanoiTowerGame
	 * @author Marcus Dillon
	 * @param N/A 
	 * @return N/A 
	 * This class is a constructor for the HanoiTowerGame class. It is used when the user provides no input for the number of 
	 * disks desired. In this case, the default number of disks is set to three and this method initializes the values of disks, 
	 * level and the gameState to PLAYING; We also initialize the three linkedStacks in the array.. We also make a call to the
	 * method firstFill to create our starting stack. 
	*/
	HanoiTowerGame() {
			this.disks = 3;
			this.level = 0;
			this.gameState = GameState.PLAYING;
			towerValues = new LinkedStack[3];
			towerValues[0] = new LinkedStack();
			towerValues[1] = new LinkedStack();
			towerValues[2] = new LinkedStack();
			firstFill(disks);

		}

	/** Defines the method HanoiTowerGame
	 * @author Marcus Dillon
	 * @param disk --> number of disks desired in the stack 
	 * @return N/A 
	 * This class is a constructor for the HanoiTowerGame class. It is used when the user provides a desired number of disks
	 * they desire to have in the stack. This method initializes the values of disks, level and the gameState to PLAYING; We also 
	 * initialize the three linkedStacks in the array. We also call the firstFill method 
	*/
	HanoiTowerGame(int disks) {
		this.disks = disks;
		this.level = 0;
		this.gameState = GameState.PLAYING;
		towerValues = new LinkedStack[3];
		towerValues[0] = new LinkedStack();
		towerValues[1] = new LinkedStack();
		towerValues[2] = new LinkedStack();
		firstFill(disks);

	}

	/** Defines the method firstFill
	 * @author Marcus Dillon
	 * @param disk --> number of disks desired in the stack 
	 * @return void 
	 * This method is used in the constuctors of the HanoiTowerGame to create the starting stack. The starting stack
	 * is a stack of a size which is dependent on the values passed in the constructor. This method creates 2 empty stacks
	 * and fills the first stack with the apprioate number of disks. 
	*/
	private void firstFill(int disks) {
		LinkedStack one = (LinkedStack) towerValues[0];
		LinkedStack two = (LinkedStack) towerValues[1];
		LinkedStack three = (LinkedStack) towerValues[2];
		int value = 0;

		for (int i = 0; i < disks; i++) {
			value = disks - i;
			one.push((int)value);
		}
		towerValues[0] = one;
		towerValues[1] = two;
		towerValues[2] = three;
		
	}

	/** Defines the method getDisk()
	 * @author Marcus Dillon
	 * @param NA
	 * @return int --> Number of disks  
	 * This method is a getter used to return the number of disks which were initially in the first stack. This 
	 * method is used in the checkWinner method to compare the value of the 3 tower with the initial value of 
	 * disks in the stack.   
	*/
	int getDisks() {
		return disks;
	}

	/** Defines the method getLevel()
	 * @author Marcus Dillon
	 * @param NA
	 * @return int --> Level
	 * This method is a getter used to return the current level (number of moves) that the player has executed. The level
	 * variable is increased each time someone plays a valid move. If the player exceeds the max amount of moves, they lose.
	 * This method is used in the play() method in Human player to print the amount of moves currently played and in the checkWinner method. 
	*/
	int getLevel() {
		return level;
	}


	/** Defines the method getMaxLevels()
	 * @author Marcus Dillon
	 * @param NA
	 * @return int --> MaxLevels
	 * This method is a getter used to return the max amount of moves a player can perform to solve the HanoiTower puzzle. This value is based
	 * on the amount disks in the stack and is determined using the following formula (maxLevels = 2*((int)Math.pow(2,disks)-1);). This value is 
	 * used in the checkWinner method and in the play() method in HumanPlayer. 
	*/
	int getMaxLevels() {
		maxLevels = 2*((int)Math.pow(2,disks)-1);
		return maxLevels;
	}

	/** Defines the method getGameState()
	 * @author Marcus Dillon
	 * @param NA
	 * @return GameState --> Current state of the game 
	 * This method is a getter used to return the current state of the game. It is used in the 
	 * HumanPlayer while loop to continue playing until the game is over (max levels or game won).
	*/
	GameState getGameState () {
		return gameState;
	}


	/** Defines the method getDisksAtTower()
	 * @author Marcus Dillon
	 * @param i --> tower index i
	 * @return int --> number of disks
	 * This method is a getter used to return the current number of disks situated at a given
	 * tower. This method is the main method used to check the size of the stack. This method is used a lot 
	 * but mainly in the play() and checkWinner() method. 
	*/
	int getDisksAtTower(int i) {
		int temp =0;
		temp = towerValues[i].size();
		return temp;
	}

	/** Defines the method play()
	 * @author Marcus Dillon
	 * @param source --> from tower
	 * @param destination --> to tower
	 * @return void
	 * This method is used to manipulate the values of the stacks (adding or removing elements based on the players input). It makes use
	 * of pop(), push() and peek() to complete this task. It uses peek to determine if the move is legitimate (not trying to put a bigger disk on a smaller disk). Push is used to add
	 * new elements to a stack and pop() is used to remove them. A legitimate move increases the value of level by 1. We also call the checkWinner() method after every move to
	 * see if this move affected the state of the game. 
	*/
	void play(int source, int destination) {
		source = source;
		destination = destination;
		Object temp;

		// if the source tower has elements and if the destination is not full 
		if (getDisksAtTower(source) != 0) {
			if (getDisksAtTower(destination) < disks) {
				if (towerValues[source].peek() != null) {
					if (getDisksAtTower(destination) > 0) {
						if ((int)towerValues[source].peek() < (int) towerValues[destination].peek()) {
							temp = towerValues[source].pop();
							towerValues[destination].push(temp);
							temp = null;
							level++;
							if (getLevel() <= getMaxLevels()) {
							checkWinner();
							}
						} else {
							System.out.println("A large disk cannot be placed on top of a small disk");
						}	
					} else if (getDisksAtTower(destination) == 0) {
						temp = towerValues[source].pop();
						towerValues[destination].push(temp);
						temp = null;
						level++;
						if (getLevel() <= getMaxLevels()) {
							checkWinner();
						}
					}
				} else {
					System.out.println("Invalid move");
				}

			}
		} else {
			System.out.println("Invalid, there are disks here at tower " + (source +1));
		}


	}

	/** Defines the method checkWinner()
	 * @author Marcus Dillon
	 * @param NA
	 * @return void
	 * This method is used check is the last move performed affected the state of the game. It accomplishes this by
	 * comparing the value of the last stack (index 2) to the value of the initial number of disk in that round. If these values
	 * are equal and this was completed within the max amount of moves, the player wins. Else, the player loses. This method is called 
	 * in the play() method in HanoiTowerGame.
	*/
	public void checkWinner(){
		if (towerValues[2].size() == disks && level <= maxLevels) {
			gameState = GameState.WINNER;
		} else if (getLevel() >= getMaxLevels()) {
			gameState = GameState.LOSER;
		}
	}

	/** Defines the method toString()
	 * @author Marcus Dillon
	 * @param NA
	 * @return String --> visual represenation of the board game. 
	 * This method is used to print out the towers/board. It accomplishes this task by utilizing the toString() method from the LinkedStack class
	 * and parses the value of that array into a temporary array. We then call the method stringToArray to convert our string 
	 * to an array of integers. We then remove the blank spaces in the array and we are left with an array of our corresponding disk values.
	 * These values are used to determine how many "-" each disk contains.  
	*/
	public String toString() {
		String returning = "";
		for (int i = 0; i < 3; i++) {
			
			String tempString = ""; 
			tempString = towerValues[i].toString();
			int [] cleanedArray = new int [tempString.length()];

			if (tempString.length() > 2) {
				cleanedArray = stringToArray(tempString);
			} else {
				cleanedArray = new int [0];
			}

			returning = returning + ("Tower " + (i+1) +"\n" );
			int numDisks = cleanedArray.length;
			//Loops through number of disks in the tower
			if (numDisks < disks) {
				for (int p = 0; p < (disks - numDisks); p++) {
					returning = returning + "\n";
				}
			}
			for (int j = 0; j < numDisks; j++) {
				//Loops through the value of each disk (to create --- for 3 etc..)
				for (int t = 0; t < cleanedArray[j]; t++) {
					returning = returning + "-";
				}
				if (i != 3 && j != (numDisks)) {
					returning = returning + "\n";
				}
			}

			
		}
		return returning;

	}

	/** Defines the method toString()
	 * @author Marcus Dillon
	 * @param phrase --> the phrase we want converted to an array of int
	 * @return int[] --> array of the numbers
	 * This method is used create an array of integers. It takes the value from the parameter (phrase) and converts it to an 
	 * array containing only numbers. We then return this array of ints so it can be used in our toString() method. 
	*/
	public int[] stringToArray(String phrase) {
		int[] returning = new int[phrase.length()];
		String[] tempString = phrase.replaceAll("\\[","").replaceAll("]", "").split(",");
		int counter = 0;
		int [] tempIntReturn;
		int tracker = 0;

		for (int i = 0; i < tempString.length; i ++) {
				returning[i] = Integer.valueOf(tempString[i]);
				if (returning[i] != 0) {
					counter++;
				}
		}
		tempIntReturn = new int[counter];
		for (int j = 0; j < returning.length; j++) {
			if (returning[j] != 0) {
				tempIntReturn[tracker] = returning[j];
				tracker++;
			}
		}
		
		return tempIntReturn;
	}
}






