//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================

/**
 * Contains a method <code>void display()</code> that all the <code>main</code>
 * methods call to show the student information. Fill the box with your personal
 * information.
 *
 * 
 */

public class StudentInfo {

    /**
     * Displays the student information: student name, id, section, etc for each
     * member of the team.
     */

    public static void display() {

        System.out.println("************************************************************");
        System.out.println("*Marcus Dillon, 300113181, ITI 1121 Section A, Assignment2 *");
        System.out.println("*                              Worked Alone                *");
        System.out.println("*                                                          *");
        System.out.println("*                                                          *");
        System.out.println("************************************************************");
        System.out.println();

    }

}
