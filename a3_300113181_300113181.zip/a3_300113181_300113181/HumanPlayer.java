//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================

/** Defines the class  HumanPlayer.
 * @author Marcus Dillon
 * @version 1.0
 * @since 1.0
 * @param N/A 
 * @return N/A 
 * This class defines the class player within the Player interface. This class is responsible for playing the game. It first prints instructions 
 * for the game to begin. It then queries the user for input until the gamestate is no longer equal to playing. This class also prints our the 
 * board after every play and is responsible for printing the score after the round was won/lost. 
*/

import java.io.Console;

public class HumanPlayer implements Player {

	// your code here
    private int score;
    Console console = System.console();


    /**
    * This method is the implementation of the method play found in the interface Player. This method 
    * is responsible for taking input from a player and calling the method play() from HanoiTower to perform
    * the given move. This method also prints the score of the game after a round was won or lost. This will be used in the
    * HanoiTower class to represent each player who is playing the game. 
    * <p>
    * @author Marcus Dillon
    * @param game --> reference to HanoiTowerGame 
    * @return void 
    */
    public void play(HanoiTowerGame game) {
        System.out.println(game);
        System.out.println("Your goal is to move 5 disks from tower 1 to 3" + "\nOnly one simple rule: No large disk on the top of a smaller one!" );
        
        while (game.getGameState() == GameState.PLAYING) {
            System.out.println("Enter the 1.source and the 2.destination towers each on a seperate line");
            String answer1 = console.readLine();
            int source = Integer.parseInt(answer1)-1;
            String answer2 = console.readLine();
            int destination = Integer.parseInt(answer2)-1;

            if (source >= 0 && source < 3) {

                if (destination >= 0 && destination <= 3) {

                    game.play(source, destination);
                    System.out.println(game);
                    System.out.println("Moves played " + game.getLevel() + " Max " + game.getMaxLevels());       

                }
            }

        } 

        if (game.getGameState() == GameState.WINNER) {
            score++;
            System.out.println("Congratulations, you have won the game!");
            System.out.println("Your score is: " + getScore());
        } else if (game.getGameState() == GameState.LOSER) {
            System.out.println("You failed to complete the game is the allocated number of moves");
            System.out.println("Your score is: " + getScore());

        }

    }
    
    /**
    * This method is the implementation of the getter method for Score. This method returns 
    * the value of score. This method is used in the play() method when we want to print the 
    * score after the round was won or lost. This variable (score) keeps track of the score throughout the 
    * entire duration of the game. 
    * <p>
    * @author Marcus Dillon
    * @param NA
    * @return int --> value of variable score  
    */
    public int getScore() {
        return this.score;
    }
}