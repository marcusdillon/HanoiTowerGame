//Student 1 full name:Marcus Dillon
//Student 2 full name:Marcus Dillon
//==================================================


/** Defines the interface Player.
 * @author Marcus Dillon
 * @version 1.0
 * @since 1.0
 * @param N/A 
 * @return N/A 
 * This class defines the interface for Player. An instance of this class is used to represent the two players which will be playnig this game.
 * There are two main method, play and getScore. The play method queries the person for input and performs that move. The getscore method returns the score for
 * the given player. 
*/
public interface Player {

    /**
    * This method will be implemented in the HumanPlayer class. It will querie the person for input and attempt to play until the game is over. Win or Max number of moves 
    * reached. 
    * <p>
    * @author Marcus Dillon
    * @param game --> reference to HanoiTowerGame 
    * @return void 
    */
    public void play(HanoiTowerGame game);

    /**
    * This method will be implemented in the HumanPlayer class. It is a getter for the Score variable. This variable tracks the score of each player throughout each game
    * if a player wins, his score increases.  
    * <p>
    * @author Marcus Dillon
    * @return int --> score 
    */
    public int getScore();
    
	
}